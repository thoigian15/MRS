tinyMCE.addI18n('en.advhr_dlg',{
normal:"Normal",
width:"Width",
widthunits:"Units",
size:"Height",
noshade:"No shadow"
});