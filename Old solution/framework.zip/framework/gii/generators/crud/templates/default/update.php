<?php
/**
 * The following variables are available in this template:
 * - $this: the CrudCode object
 */
?>
<?php echo "<?php\n";
echo "//\$this->pageTitle=Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), '');\n";
echo "//\$this->keywords=Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), '');\n";
echo "//\$this->description=Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), '');\n";
echo "//\$this->setOpenGraphProtocol(array(
//    'og:title' => Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), ''),
//    'og:type' => 'website',
//    'og:image' => Common::generateHyperLink(Yii::app()->request->baseUrl . '/images/logos/logo.png'),
//    'og:url' => Common::getCurrentUrl(),
//));\n";
echo "//\$this->setRobots('noindex, follow');\n"; ?>
/* @var $this <?php echo $this->getControllerClass(); ?> */
/* @var $model <?php echo $this->getModelClass(); ?> */

<?php
$nameColumn=$this->guessNameColumn($this->tableSchema->columns);
$label=$this->pluralize($this->class2name($this->modelClass));
echo "\$this->breadcrumbs=array(
	Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), '$label')=>array('index'),
	\$model->{$nameColumn}=>array('view','id'=>\$model->{$this->tableSchema->primaryKey}),
	Yii::t(Common::generateMessageCategory(null, 'CoreMessage'), 'Update'),
);\n";
?>

$this->menu=array(
    array('label'=>Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), 'List <?php echo $this->modelClass; ?>'), 'url'=>array('index')),
    array('label'=>Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), 'Create <?php echo $this->modelClass; ?>'), 'url'=>array('create')),
    array('label'=>Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), 'View <?php echo $this->modelClass; ?>'), 'url'=>array('view', 'id'=>$model-><?php echo $this->tableSchema->primaryKey; ?>)),
    array('label'=>Yii::t(Common::generateMessageCategory(__FILE__, __CLASS__), 'Manage <?php echo $this->modelClass; ?>'), 'url'=>array('admin')),
);
?>

<h1><?php echo "<?php echo Yii::t(Common::generateMessageCategory(__FILE__,__CLASS__), 'Update ".$this->modelClass; ?><?php echo "');?> #<?php echo \$model->{$this->tableSchema->primaryKey}; ?>";?></h1>

<?php echo "<?php echo \$this->renderPartial('_form', array('model'=>\$model)); ?>"; ?>